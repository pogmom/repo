	var wallpaper = "url('../../Xenimated/"+wallgif+"')";
	document.body.style.backgroundImage = wallpaper;
